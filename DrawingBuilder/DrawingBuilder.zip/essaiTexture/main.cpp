#include "theMain.h"
#include "leMain.h"
int main()
{
	return theMain();
}
